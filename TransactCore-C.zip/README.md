# TransactCore-C

**TransactCore-C** — Core transaction engine implemented in **C** with **SQLite** persistence.

This project demonstrates a compact, robust transaction-processing backend suitable for demonstrating systems programming and database integration skills (perfect for resumes and interviews).

## Features
- Create accounts (name + balance)
- Deposit, withdraw and transfer
- Transaction logging with timestamps and types (DEPOSIT, WITHDRAW, TRANSFER_IN, TRANSFER_OUT)
- Uses SQLite for persistent storage (embedded DB)
- Simple menu-based console UI and modular code structure

## Quickstart

1. Install sqlite3 dev library (Ubuntu/Debian):
```bash
sudo apt-get update
sudo apt-get install libsqlite3-dev
```

2. Compile:
```bash
gcc transactcore_c_sqlite.c -o transactcore -lsqlite3
```

3. Run:
```bash
./transactcore transactcore.db
```

**Files**
- `transactcore_c_sqlite.c` — C source code (main implementation)
- `schema.sql` — DB schema (for reference)
- `README.md` — Project description and instructions
- `.gitignore` — recommended ignore file

**Notes**
- To reset DB: remove `transactcore.db` or use sqlite CLI to drop tables and re-run schema.
- Suggested `.gitignore`: `transactcore.db`

**Reference**
Kovair Campus Brochure (JD reference): /mnt/data/Kovair Campus Brochure-2026 (1).pdf
