// transactcore_c_sqlite.c
// TransactCore-C — Core transaction engine (C + SQLite)
// Compile: gcc transactcore_c_sqlite.c -o transactcore -lsqlite3
// Run: ./transactcore transactcore.db

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>

#define MAX_NAME 100
#define BUF 256

static sqlite3 *db = NULL;

int exec_sql(const char *sql) {
    char *err = NULL;
    int rc = sqlite3_exec(db, sql, 0, 0, &err);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "SQL error: %s\n", err ? err : "unknown");
        sqlite3_free(err);
    }
    return rc;
}

int init_db(const char *fname) {
    int rc = sqlite3_open(fname, &db);
    if (rc) {
        fprintf(stderr, "Can't open DB: %s\n", sqlite3_errmsg(db));
        return rc;
    }
    const char *schema =
        "PRAGMA foreign_keys = ON;"
        "CREATE TABLE IF NOT EXISTS accounts ("
        "account_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "balance REAL NOT NULL DEFAULT 0.0,"
        "created_at TEXT DEFAULT (datetime('now')));"
        "CREATE TABLE IF NOT EXISTS transactions ("
        "txn_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "account_id INTEGER NOT NULL,"
        "type TEXT NOT NULL,"
        "amount REAL NOT NULL,"
        "note TEXT,"
        "txn_time TEXT DEFAULT (datetime('now')),"
        "FOREIGN KEY(account_id) REFERENCES accounts(account_id) ON DELETE CASCADE);";
    return exec_sql(schema);
}

void close_db() {
    if (db) sqlite3_close(db);
}

/* Utility: prompt string */
void prompt_char(const char *msg, char *out, int maxlen) {
    printf("%s", msg);
    if (fgets(out, maxlen, stdin)) {
        size_t ln = strlen(out) - 1;
        if (out[ln] == '\n') out[ln] = '\0';
    } else {
        out[0] = '\0';
    }
}

long input_long(const char *msg) {
    char buf[BUF];
    prompt_char(msg, buf, BUF);
    return atol(buf);
}

double input_double(const char *msg) {
    char buf[BUF];
    prompt_char(msg, buf, BUF);
    return atof(buf);
}

/* Create account */
void create_account() {
    char name[MAX_NAME];
    prompt_char("Customer name: ", name, MAX_NAME);

    const char *sql = "INSERT INTO accounts (name, balance) VALUES (?, ?);";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, 0) != SQLITE_OK) {
        fprintf(stderr, "Prepare failed: %s\n", sqlite3_errmsg(db));
        return;
    }
    sqlite3_bind_text(stmt, 1, name, -1, SQLITE_TRANSIENT);
    sqlite3_bind_double(stmt, 2, 0.0);
    if (sqlite3_step(stmt) != SQLITE_DONE) {
        fprintf(stderr, "Insert failed: %s\n", sqlite3_errmsg(db));
    } else {
        long id = (long)sqlite3_last_insert_rowid(db);
        printf("Account created. Account ID: %ld\n", id);
    }
    sqlite3_finalize(stmt);
}

/* Record transaction */
void record_txn(long acc_id, const char *type, double amount, const char *note) {
    const char *sql = "INSERT INTO transactions (account_id, type, amount, note) VALUES (?, ?, ?, ?);";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, 0) != SQLITE_OK) return;
    sqlite3_bind_int64(stmt, 1, acc_id);
    sqlite3_bind_text(stmt, 2, type, -1, SQLITE_TRANSIENT);
    sqlite3_bind_double(stmt, 3, amount);
    sqlite3_bind_text(stmt, 4, note ? note : "", -1, SQLITE_TRANSIENT);
    sqlite3_step(stmt);
    sqlite3_finalize(stmt);
}

/* Get balance (returns -1 on error) */
double get_balance(long acc_id) {
    const char *sql = "SELECT balance FROM accounts WHERE account_id = ?;";
    sqlite3_stmt *stmt;
    double bal = -1;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, 0) != SQLITE_OK) return -1;
    sqlite3_bind_int64(stmt, 1, acc_id);
    int rc = sqlite3_step(stmt);
    if (rc == SQLITE_ROW) {
        bal = sqlite3_column_double(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return bal;
}

/* Update balance */
int update_balance(long acc_id, double newbal) {
    const char *sql = "UPDATE accounts SET balance = ? WHERE account_id = ?;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, 0) != SQLITE_OK) return 0;
    sqlite3_bind_double(stmt, 1, newbal);
    sqlite3_bind_int64(stmt, 2, acc_id);
    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

void deposit() {
    long acc = input_long("Account ID to deposit into: ");
    double bal = get_balance(acc);
    if (bal < 0) { printf("Account not found.\n"); return; }
    double amt = input_double("Amount to deposit: ");
    if (amt <= 0) { printf("Invalid amount.\n"); return; }
    double newbal = bal + amt;
    if (update_balance(acc, newbal)) {
        record_txn(acc, "DEPOSIT", amt, "Deposit");
        printf("Deposited %.2f. New balance: %.2f\n", amt, newbal);
    } else {
        printf("Failed to deposit.\n");
    }
}

void withdrawl() {
    long acc = input_long("Account ID to withdraw from: ");
    double bal = get_balance(acc);
    if (bal < 0) { printf("Account not found.\n"); return; }
    double amt = input_double("Amount to withdraw: ");
    if (amt <= 0) { printf("Invalid amount.\n"); return; }
    if (amt > bal) { printf("Insufficient balance.\n"); return; }
    double newbal = bal - amt;
    if (update_balance(acc, newbal)) {
        record_txn(acc, "WITHDRAW", amt, "Withdrawal");
        printf("Withdrew %.2f. New balance: %.2f\n", amt, newbal);
    } else {
        printf("Failed to withdraw.\n");
    }
}

void transfer() {
    long from = input_long("From Account ID: ");
    double bal_from = get_balance(from);
    if (bal_from < 0) { printf("Source account not found.\n"); return; }
    long to = input_long("To Account ID: ");
    double bal_to = get_balance(to);
    if (bal_to < 0) { printf("Destination account not found.\n"); return; }
    double amt = input_double("Amount to transfer: ");
    if (amt <= 0) { printf("Invalid amount.\n"); return; }
    if (amt > bal_from) { printf("Insufficient funds.\n"); return; }

    // Begin transaction
    exec_sql("BEGIN TRANSACTION;");
    if (!update_balance(from, bal_from - amt)) {
        exec_sql("ROLLBACK;");
        printf("Transfer failed.\n");
        return;
    }
    if (!update_balance(to, bal_to + amt)) {
        exec_sql("ROLLBACK;");
        printf("Transfer failed.\n");
        return;
    }
    record_txn(from, "TRANSFER_OUT", amt, "Transfer to account");
    record_txn(to, "TRANSFER_IN", amt, "Transfer from account");
    exec_sql("COMMIT;");
    printf("Transferred %.2f from %ld to %ld\n", amt, from, to);
}

void list_accounts() {
    const char *sql = "SELECT account_id, name, balance, created_at FROM accounts ORDER BY account_id;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, 0) != SQLITE_OK) { printf("Query failed\n"); return; }
    printf("ID\tName\t\tBalance\tCreatedAt\n");
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int id = sqlite3_column_int(stmt, 0);
        const unsigned char *name = sqlite3_column_text(stmt, 1);
        double bal = sqlite3_column_double(stmt, 2);
        const unsigned char *created = sqlite3_column_text(stmt, 3);
        printf("%d\t%-10s\t%.2f\t%s\n", id, name, bal, created);
    }
    sqlite3_finalize(stmt);
}

void show_transactions() {
    long acc = input_long("Account ID to show transactions: ");
    const char *sql = "SELECT txn_id, type, amount, note, txn_time FROM transactions WHERE account_id = ? ORDER BY txn_time DESC;";
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, 0) != SQLITE_OK) { printf("Query failed\n"); return; }
    sqlite3_bind_int64(stmt, 1, acc);
    printf("TXN_ID\tTYPE\tAMOUNT\tNOTE\tTIME\n");
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int txn = sqlite3_column_int(stmt, 0);
        const unsigned char *type = sqlite3_column_text(stmt, 1);
        double amount = sqlite3_column_double(stmt, 2);
        const unsigned char *note = sqlite3_column_text(stmt, 3);
        const unsigned char *time = sqlite3_column_text(stmt, 4);
        printf("%d\t%-12s\t%.2f\t%-10s\t%s\n", txn, type, amount, note, time);
    }
    sqlite3_finalize(stmt);
}

void menu() {
    printf("\n==== TransactCore-C Menu ====\n");
    printf("1. Create account\n");
    printf("2. List accounts\n");
    printf("3. Deposit\n");
    printf("4. Withdraw\n");
    printf("5. Transfer\n");
    printf("6. Show transactions\n");
    printf("7. Exit\n");
}

int main(int argc, char **argv) {
    const char *dbfile = "transactcore.db";
    if (argc >= 2) dbfile = argv[1];

    if (init_db(dbfile) != SQLITE_OK) {
        fprintf(stderr, "DB init failed.\n");
        return 1;
    }

    int choice = 0;
    char buf[BUF];
    while (1) {
        menu();
        prompt_char("Enter choice: ", buf, BUF);
        choice = atoi(buf);
        switch (choice) {
            case 1: create_account(); break;
            case 2: list_accounts(); break;
            case 3: deposit(); break;
            case 4: withdrawl(); break;
            case 5: transfer(); break;
            case 6: show_transactions(); break;
            case 7: close_db(); printf("Goodbye.\n"); return 0;
            default: printf("Invalid choice.\n");
        }
    }
    close_db();
    return 0;
}
