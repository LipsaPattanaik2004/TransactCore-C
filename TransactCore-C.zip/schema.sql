-- schema.sql
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS accounts (
    account_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    balance REAL NOT NULL DEFAULT 0.0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS transactions (
    txn_id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    type TEXT NOT NULL,       -- DEPOSIT | WITHDRAW | TRANSFER_OUT | TRANSFER_IN
    amount REAL NOT NULL,
    note TEXT,
    txn_time TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(account_id) REFERENCES accounts(account_id) ON DELETE CASCADE
);
